package com.ing.stepdefinition;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.ing.basepage.HomePageBase;
import com.ing.pages.SavingMaximiserPage;
import com.ing.utilities.ReadData_Property;
import com.ing.utilities.ScreenShot;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class StepDefinitionWithDataTable {

	

	@Given("^Open the web application$")
	public void open_the_web_application() throws Throwable {
		
		//Launching the browser with particular URL
		HomePageBase.driverInitialization();

	}
	

	@When("I complete the account creation form with below details and click on continue button")
	public void i_complete_the_account_open_Form_details(DataTable dataTable) throws Exception {

		SavingMaximiserPage sapObject = new SavingMaximiserPage(HomePageBase.driver);
		// Fetch data from data table
		List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);
		sapObject.fillDetailsInSAP(list);
		sapObject.clickOnContinueButton();
	}

	@Then("Verify Successful Navigation to next page")
	public void verify_successful_navigation_to_next_page() throws Exception {
		SavingMaximiserPage sapObject = new SavingMaximiserPage(HomePageBase.driver);
		if (sapObject.getproceedButton().isDisplayed()) {
			System.out.println("User navigated successfully to next page");
		} 
		String tcn = ReadData_Property.getproper("tcn");
		ScreenShot.GetScreenShot(HomePageBase.driver, tcn);
		HomePageBase.driver.quit();
	}
	
	@When("I complete the account creation form with below details for nationality field and click on continue button")
	public void i_complete_the_account_creation_form_with_below_details_for_nationality_field_and_click_on_continue_button(io.cucumber.datatable.DataTable dataTable) throws Exception {
		SavingMaximiserPage sapObject = new SavingMaximiserPage(HomePageBase.driver);
		// Fetch data from data table
		List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);
		sapObject.fillInvalidDetailsInSAP(list);
		sapObject.clickOnContinueButton();
	}

	
	@Then("Verify unsuccessful navigation")
	public void verify_unsuccessful_navigation_to_next_page() throws Exception {
		SavingMaximiserPage sapObject = new SavingMaximiserPage(HomePageBase.driver);
		if (sapObject.getContinueButton().isDisplayed()) {
			System.out.println("User dint Navigate to next page");

		}
		HomePageBase.driver.quit();

	   }
	
	
}

