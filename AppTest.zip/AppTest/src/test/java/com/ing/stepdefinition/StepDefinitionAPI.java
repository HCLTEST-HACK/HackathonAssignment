package com.ing.stepdefinition;

import com.ing.pages.GetAPI_Country;
import com.ing.utilities.ReadData_Property;

import cucumber.api.java.en.*;

public class StepDefinitionAPI extends GetAPI_Country{
	

@Given("Get the base URL and param details retrieve india")
public void get_the_base_URL_and_param_details_retrieve_india() throws Exception {
	
	String bPath = ReadData_Property.getproper("languagebasepath");
	GetAPI_Country.setBasepath(bPath);
    
}

@When("Send the get request")
public void send_the_get_request() {
	
	GetAPI_Country.getresonse();
   
}

@Then("Verify Successful response")
public void verify_Successful_response() {
   GetAPI_Country.verifyResponse();
}

@Then("Assert that  Hindi language is returned for india")
public void assert_that_Hindi_language_is_returned_for_india() throws Exception {
	
	GetAPI_Country.validateLanguage();
	
   
}

@Then("Assert that the Calling Codes for India")
public void assert_that_the_Calling_Codes_for_India() throws Exception {
	GetAPI_Country.validateCountryCode();
}


@Given("Get the base URL and param details retrieve country name and timezone")
public void get_the_base_URL_and_param_details_retrieve_country_name_and_timezone() {
	
	GetAPI_Country.getBaseCountry();
    
}


@Then("Return the name of the country which is furthest ahead of UTC")
public void return_the_name_of_the_country_which_is_furthest_ahead_of_UTC() {
	
	GetAPI_Country.returnUTC();

}

      

}
