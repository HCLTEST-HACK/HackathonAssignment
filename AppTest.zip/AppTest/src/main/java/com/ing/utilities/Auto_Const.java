package com.ing.utilities;

public interface Auto_Const {
	
	 String GECKO_KEY="webdriver.gecko.driver";
     String GECKO_VALUE="./drivers/geckodriver.exe";

     String CHROME_KEY="webdriver.chrome.driver";
     String CHROME_VALUE="./drivers/chromedriver.exe";

     String PROPERTY_FILE="./src/main/java/config.properties";
     
     String PHOTO_PATH="./ScreenShots";

}
