package com.ing.utilities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebElement;

import com.ing.basepage.HomePageBase;

public class Utility {

	public static void selectRadioButtonResponses(String stringText, WebDriver driver) throws Exception {
		String strArray[] = stringText.split(",");
		for (int i = 0; i < strArray.length; i++) {
			String text = strArray[i];
			Thread.sleep(3000);
			
			driver.findElement(By.xpath("//label[contains(text(),'" + text + "')]")).click();
			//WebElement element=driver.findElement(By.xpath("//label[contains(text(),'" + text + "')]"));
			
			//((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
		}
		
		// driver.findElement(By.xpath("//label[contains(text(),'"+text+"')]/preceding-sibling::input")).click();
	}

	public static void selectOption(String text, WebDriver driver) throws Exception {
		
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='" + text + "']")).click();
	}
	
	public static  String getCurrentDateInStringFormat()
    {
           Date todaysDate = new Date();
           String testDateString=null;
           DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
           try
           {
               //format() method Formats a Date into a date/time string. 
               testDateString = df.format(todaysDate);
               System.out.println("String in dd/MM/yyyy format is: " + testDateString);

           }
           catch (Exception ex ){
              System.out.println(ex);
           }
           return testDateString;
    }
		
	
}
