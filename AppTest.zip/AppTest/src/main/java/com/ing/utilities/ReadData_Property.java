package com.ing.utilities;
import java.io.FileInputStream;
import java.util.Properties;
public class ReadData_Property implements Auto_Const {

		public static String getproper(String key) throws Exception
		{
			
			 Properties p = new Properties();
			// p.load(new FileInputStream("./src/main/java/config.properties"));
			 p.load(new FileInputStream(PROPERTY_FILE));
			 String data = p.getProperty(key);
			 return data;
			
			
		}
	}

