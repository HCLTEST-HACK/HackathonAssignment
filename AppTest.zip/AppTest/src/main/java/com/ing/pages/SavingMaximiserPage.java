package com.ing.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.ing.basepage.HomePageBase;
import com.ing.utilities.Utility;

public class SavingMaximiserPage extends HomePageBase {

	// private WebDriver driver;

	@FindBy(xpath = "//h1[text()='Open a Savings Maximiser']")
	private WebElement savingsMaximiserText;

	@FindBy(css = "span#securityQuestion_validationErrorSpan")
	private WebElement securityQuestionError;

	public WebElement getSecurityQuestionError() {
		return securityQuestionError;
	}

	@FindBy(xpath = "//span[text()='No Result']")
	private WebElement noResultSection;

	@FindBy(xpath = "//span[text()='date should be in accepted range']")
	private WebElement dateRangeValidationMessage;

	public WebElement getDateRangeValidationMessage() {
		return dateRangeValidationMessage;
	}

	public WebElement getNoResultSection() {
		return noResultSection;
	}

	@FindBy(xpath = "//span[text()='Please try again - you need a valid country name']")
	private WebElement errorMessageAtNationality;

	public WebElement getErrorMessageAtNationality() {
		return errorMessageAtNationality;
	}

	public WebElement getsavingsMaximiserText() {
		return savingsMaximiserText;
	}

	@FindBy(xpath = "//input[@aria-label='Nationality (Citizenship)']")
	private WebElement nationality;
	@FindBy(xpath = "//button[@id='proceedButton']")
	private WebElement proceedButton;

	public WebElement getproceedButton() {
		return proceedButton;
	}

	public WebElement getNationality() {
		return nationality;
	}

	@FindBy(xpath = "//*[@id='dropMenuItem']/div/paper-item[1]")
	private WebElement dropMenuItems;

	public WebElement getDropMenuItems() {
		return dropMenuItems;
	}

	@FindBy(xpath = "//input[@id='titleDropdown_targetInput']")
	private WebElement titleDropDown;

	public WebElement getTitleDropDown() {
		return titleDropDown;
	}

	@FindBy(xpath = "//span[text()='Mr']")
	private WebElement salSelection;

	public WebElement getSalSelection() {
		return salSelection;
	}

	@FindBy(xpath = "//input[@aria-label='Given name']")
	private WebElement givenName;

	public WebElement getGivenName() {
		return givenName;
	}

	@FindBy(xpath = "//input[@aria-label='Middle name (if you have one)']")
	private WebElement middleName;

	public WebElement getMiddleName() {
		return middleName;
	}

	public WebElement getFamiltyName() {
		return familtyName;
	}

	public WebElement getDobTextBox() {
		return dobTextBox;
	}

	public WebElement getPlaceOfBirthTextBox() {
		return placeOfBirthTextBox;
	}

	public WebElement getCountryOfBirthTextBox() {
		return countryOfBirthTextBox;
	}

	public WebElement getEmailAddressTextbox() {
		return emailAddressTextbox;
	}

	public WebElement getMobileTextBox() {
		return mobileTextBox;
	}

	public WebElement getAddressTextBox() {
		return addressTextBox;
	}

	public WebElement getSameasResidentialCheckbox() {
		return sameasResidentialCheckbox;
	}

	public WebElement getMaidenName() {
		return maidenName;
	}

	public WebElement getContinueButton() {
		return continueButton;
	}

	@FindBy(xpath = "//input[@aria-label='Family name']")
	private WebElement familtyName;

	@FindBy(xpath = "(//input[contains(@aria-label,'Date of birth')])[1]")
	private WebElement dobTextBox;

	@FindBy(xpath = "//input[@aria-label='Place of birth']")
	private WebElement placeOfBirthTextBox;

	@FindBy(xpath = "//input[@aria-label='Country of birth']")
	private WebElement countryOfBirthTextBox;

	@FindBy(xpath = "//input[@aria-label='Email address']")
	private WebElement emailAddressTextbox;

	@FindBy(xpath = "//input[@aria-label='Mobile']")
	private WebElement mobileTextBox;

	@FindBy(xpath = "//input[@aria-label='Enter address']")
	private WebElement addressTextBox;

	@FindBy(xpath = "//span[text()='Same as residential address']")
	private WebElement sameasResidentialCheckbox;

	@FindBy(xpath = "//input[contains(@aria-label,'maiden name')]")
	private WebElement maidenName;

	@FindBy(xpath = "//span[text()='Continue']")
	private WebElement continueButton;

	public SavingMaximiserPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void fillDetailsInSAP(List<Map<String, String>> list) throws Exception {

		Actions actionObject = new Actions(driver);
		// if (getsavingsMaximiserText().getText().equals("Open a Savings
		// Accelerator")) {
		// if (getsavingsMaximiserText().getText().contains("Open a Savings
		// Accelerator")){

		Utility.selectRadioButtonResponses("Single,Male,Three or more years,No", driver);

		// Nationality field

		getNationality().sendKeys(list.get(0).get("Nationality"));
		System.out.println("NAtionality value:" + list.get(0).get("Nationality"));
		actionObject.sendKeys(Keys.TAB).build().perform();

		if (getDropMenuItems().isDisplayed()) {
			getDropMenuItems().click();

			Thread.sleep(3000);
			actionObject.moveToElement(getTitleDropDown()).click().perform();
			Utility.selectOption(list.get(0).get("Title"), driver);

		}

		else if (getErrorMessageAtNationality().isDisplayed()) {
			System.out.println("Please enter valid user name");
			actionObject.moveToElement(getContinueButton()).click().perform();
		}

		else if (getNoResultSection().isDisplayed()) {
			Thread.sleep(3000);
			getNationality().click();

			if (getErrorMessageAtNationality().isDisplayed()) {
				System.out.println("Please enter valid user name");
			}
			actionObject.moveToElement(getTitleDropDown()).click().perform();
			Utility.selectOption(list.get(0).get("Title"), driver);

		}

		getGivenName().sendKeys(list.get(0).get("GivenName"));

		getMiddleName().sendKeys(list.get(0).get("MiddleName"));
		getFamiltyName().sendKeys(list.get(0).get("FamilyName"));

		if (list.get(0).get("DateOfBirth").equals(Utility.getCurrentDateInStringFormat())) {
			getDobTextBox().sendKeys(list.get(0).get("DateOfBirth"));
			actionObject.moveToElement(getPlaceOfBirthTextBox()).click().build().perform();
			Thread.sleep(3000);
			System.out.println(getDateRangeValidationMessage().isDisplayed());
		} else {
			getDobTextBox().sendKeys(list.get(0).get("DateOfBirth"));
			actionObject.moveToElement(getPlaceOfBirthTextBox()).click().build().perform();
		}
		getPlaceOfBirthTextBox().sendKeys(list.get(0).get("PlaceOfBirth"));
		getCountryOfBirthTextBox().sendKeys(list.get(0).get("CountryOfBirth"));

		actionObject.sendKeys(Keys.TAB).build().perform();
		actionObject.sendKeys(Keys.ENTER).build().perform();

		getEmailAddressTextbox().sendKeys(list.get(0).get("EmailAddress"));
		getMobileTextBox().sendKeys(list.get(0).get("Mobile"));
		getAddressTextBox().sendKeys(list.get(0).get("EnterAddress"));

		Thread.sleep(3000);

		actionObject.sendKeys(Keys.TAB).build().perform();
		actionObject.sendKeys(Keys.ENTER).build().perform();

		getSameasResidentialCheckbox().click();

		getMaidenName().sendKeys(list.get(0).get("MaidenName"));

		getContinueButton().click();
		System.out.println(getSecurityQuestionError().isDisplayed());

	}

	public void fillInvalidDetailsInSAP(List<Map<String, String>> list) throws Exception {

		Actions actionObject = new Actions(driver);
		// if (getsavingsMaximiserText().getText().equals("Open a Savings
		// Accelerator")) {
		// if (getsavingsMaximiserText().getText().contains("Open a Savings
		// Accelerator")){

		Utility.selectRadioButtonResponses("Single,Male,Three or more years,No", driver);

		// Nationality field

		getNationality().sendKeys(list.get(0).get("Nationality"));
		System.out.println("NAtionality value:" + list.get(0).get("Nationality"));
		actionObject.sendKeys(Keys.TAB).build().perform();

		if (getDropMenuItems().isDisplayed()) {
			getDropMenuItems().click();

			Thread.sleep(3000);
			actionObject.moveToElement(getTitleDropDown()).click().perform();
			Utility.selectOption(list.get(0).get("Title"), driver);

		}

		else if (getErrorMessageAtNationality().isDisplayed()) {
			System.out.println("Please enter valid user name");
			actionObject.moveToElement(getContinueButton()).click().perform();
		}

		else if (getNoResultSection().isDisplayed()) {
			Thread.sleep(3000);
			getNationality().click();

			if (getErrorMessageAtNationality().isDisplayed()) {
				System.out.println("Please enter valid user name");
			}
			actionObject.moveToElement(getTitleDropDown()).click().perform();
			Utility.selectOption(list.get(0).get("Title"), driver);

		}

		getGivenName().sendKeys(list.get(0).get("GivenName"));

		getMiddleName().sendKeys(list.get(0).get("MiddleName"));
		getFamiltyName().sendKeys(list.get(0).get("FamilyName"));

		if (list.get(0).get("DateOfBirth").equals(Utility.getCurrentDateInStringFormat())) {
			getDobTextBox().sendKeys(list.get(0).get("DateOfBirth"));
			actionObject.moveToElement(getPlaceOfBirthTextBox()).click().build().perform();
			Thread.sleep(3000);
			System.out.println(getDateRangeValidationMessage().isDisplayed());
		} else {
			getDobTextBox().sendKeys(list.get(0).get("DateOfBirth"));
			actionObject.moveToElement(getPlaceOfBirthTextBox()).click().build().perform();
		}
		getPlaceOfBirthTextBox().sendKeys(list.get(0).get("PlaceOfBirth"));
		getCountryOfBirthTextBox().sendKeys(list.get(0).get("CountryOfBirth"));

		actionObject.sendKeys(Keys.TAB).build().perform();
		actionObject.sendKeys(Keys.ENTER).build().perform();

		getEmailAddressTextbox().sendKeys(list.get(0).get("EmailAddress"));
		getMobileTextBox().sendKeys(list.get(0).get("Mobile"));
		getAddressTextBox().sendKeys(list.get(0).get("EnterAddress"));

		Thread.sleep(3000);

		actionObject.sendKeys(Keys.TAB).build().perform();
		actionObject.sendKeys(Keys.ENTER).build().perform();

		getSameasResidentialCheckbox().click();

		getMaidenName().sendKeys(list.get(0).get("MaidenName"));

		getContinueButton().click();
		System.out.println(getSecurityQuestionError().isDisplayed());

	}

	public void clickOnContinueButton() {
		// Click on continue

		getContinueButton().click();
	}

}
