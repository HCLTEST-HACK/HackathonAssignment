package com.ing.pages;

import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.ing.utilities.ReadData_Property;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import junit.framework.Assert;

public class GetAPI_Country {
	
	static Response response;
	static List languages;
	static List callingCode;
	
	public  static void setBasepath(String bPath)
	{
	     //Setting base url 
		RestAssured.baseURI="https://restcountries.eu/rest/v2";
	    
		//setting base path for retrieve Country India
		//RestAssured.basePath="/name/India?fullText=true";
		RestAssured.basePath=bPath;
		RestAssured.useRelaxedHTTPSValidation();
		
	}
	
	public static void getresonse(){
		
		response=given().when().get();
		
	}
	
	public static void verifyResponse(){
		
		System.out.println("Response:"+response.asString());
		JsonPath jsonPath = new JsonPath(response.asString());
		
		languages = jsonPath.get("[1].languages.name");
		callingCode=jsonPath.get("[1].callingCodes");
		System.out.println("Language:"+languages.get(0));
		System.out.println("CallingCode:"+callingCode.get(0));
		
	}
	
	public static void validateLanguage() throws Exception{
		String indianLanguage = languages.get(0).toString();
		String lang = ReadData_Property.getproper("indianlanguage");
		Assert.assertEquals(lang, indianLanguage);
		
	}
	
	public static void validateCountryCode() throws Exception{
		String indianCallingCode = callingCode.get(0).toString();
		String code = ReadData_Property.getproper("indiancallingcode");
		Assert.assertEquals(code, indianCallingCode);
		
	}
	
	public static void getBaseCountry(){
		
		  RestAssured.baseURI="https://restcountries.eu/rest/v2";
		     RestAssured.basePath="/all?fields=name;timezones";
		     RestAssured.useRelaxedHTTPSValidation();
	}
	
	public static void returnUTC(){
		
		JsonPath json = new JsonPath(response.asString());
	    // TreeMap<String , List> resultMap = new TreeMap<String , List>(Collections.reverseOrder());
	     
	    TreeMap<String , List> resultMap = new TreeMap<String , List>();

//	     HashMap<String, String> countryName= new HashMap<String, String>();
	     Map temp = null ;
	     ArrayList<String> timeZoneList;
	     List<String> tempList  ;
	     int arrSize = json.getList(".").size();

	     for (int i=0;i<arrSize;i++)
	     {
	    	 temp=json.getMap("["+i+"]");
	    	 timeZoneList = (ArrayList<String>) temp.get("timezones");
	    	  
	    	  for(int k=0; k<timeZoneList.size(); k++)
	          {
	    		  tempList = new ArrayList<String>();
	              if(!timeZoneList.get(k).contains("-"))
	    	      {
	    	            
	    	         if (resultMap.containsKey(timeZoneList.get(k)))
	    	         {
	    	        	 tempList = resultMap.get(timeZoneList.get(k));
	                     tempList.add((String)temp.get("name"));
	                     resultMap.put(timeZoneList.get(k), tempList );
	                   }
	    	    	  else
	    	    	  {
	    	    	     tempList.add((String)temp.get("name"));
	    	    	     resultMap.put(timeZoneList.get(k), tempList);
	    	          }
	    	         
	    	      }
	              
	          }
	    	         
	    	       
	    	    	  
	    	    	 
	     }
	     System.out.println(resultMap);
		    List<String> countryList = resultMap.get(resultMap.lastKey());
		   // System.out.println("country which is furthest ahead of UTC:"+countryList); 
		    
		    for(String str:countryList){
		    	
			    System.out.println("Country furthest ahead of UTC:"+str); 

		    }
	}
	

}
